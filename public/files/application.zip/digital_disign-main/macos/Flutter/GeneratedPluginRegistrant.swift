//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import location

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  LocationPlugin.register(with: registry.registrar(forPlugin: "LocationPlugin"))
}
